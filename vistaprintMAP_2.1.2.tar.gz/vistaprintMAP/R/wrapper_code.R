#' wrapper code which in turn calls other MAP functions and load the necessary packages
#' @description wrapper code that calls otehr MAP functions - to provide you a one line code execution for MAP
#' @return  a series of data frames, lists and visual output
#' @param test_type_id platform id: 1 for CMSR, 2 for CRM, 3 for PPP, 4 for maximizer etc
#' @param test_id the test_id for your test
#' @param start_date Start date for your visitor sproc
#' @param end_date end date for your visitor sproc
#' @param FVT Should you use FVT for your analysis (FVT = 1 means use FVT for analysis, FVT = 0 means use FVA for your analysis)
#' @param page_spots List of page_spot_ids to be used as a filter for your visitor sproc
#' @param splash_ids List of splash_url_ids to be used as a filter for your visior sproc
#' @param control_id the test_sub_id against which all other test_sub_id's will be compared
#' @param sql_connection the ODBC connection name (windows authenticated)
#' @param gm_low  Cutoff point for the negative GM orders - Most use cases with fall within 0.0001 and 0.002
#' @param gm_high  Cutoff point for high GM values per ordering visitors - Most use cases with fall within 0.95 and 1.0
#' @param bookings_high  Cutoff point for high booking values per ordering visitors  - Most use cases with fall within 0.95 and 1.0
#' @param run_sql_sproc 2 means run all sql sproc (visitor, order, CARE), 1 means run all sql sproc except visitor, 0 means don't run the sprocs
#' @param no_days_to_order Orders placed within this time frame from first touch point,is pulled in the order module
#' @param filter_out_reorders Do you want to filter out reorders from CARE credit rate analysis (1 means filter out, 0 means include reorder in Credit rate analysis)
#' @param contact_days_threshold How many days from the first visitor touch point, do you want to consider calls to CARE for contact rate analysis
#' @param cohort_dimensions dimensions for which you want to do cohort analysis
#' @param days_to_consider No of days given for the visitor to convert from the first touch point
#' @param include_hoppers  0 means remove hopper, 1 means keep visitor level hopper in analysis
#' @param exposed_to_test  only consider visitor who were exposed to test in analysis (0 can be used for CRM test, everyone else should use 1)
#' @param x_axis_day_interval the date interval to be used for any plots by day
#' @param additional_constraint additional where clause used to filter your data
#' @param TCR  Tail criteria for CR metric (do you want to perform 1 or 2 tail analysis on each of the 5 metrics. 0 = 2tail, -1 = negative 1 tail, 1 = postive one tail analysis)
#' @param TBPB Tail criteria for Bookings per buyer metric
#' @param TGPB Tail level for gm per buyer metric
#' @param TBPV Tail level for bookings per visitor metric
#' @param TGPV Tail level for gm per visitor metric
#' @param more_visuals gives additional graph if avaialble from  each modules
#' @param demo_mode 1 means you are running MAP for demo. It prints all the graphs, but doesn't store the summary data in common directory
#' @examples
#' map_wrapper(test_id = 6352, test_type_id = 1, control_id = 25801)
#' map_wrapper(test_id = 1, test_type_id = 2, control_id = 0, run_sql_sproc = 0)
#' map_wrapper(test_id = 6352,control_id = 25801 , test_type_id = 1, run_sql_sproc = 0,sql_connection = "RSQL")
#' map_wrapper(test_id = 1, test_type_id = 2, control_id = 0, run_sql_sproc = 0,sql_connection = "RSQL",gm_low = 0.0001,gm_high = 0.99,bookings_high = 0.99,cohort_dimensions = c("is_new","region"))
#' @export
map_wrapper <- function(test_id
                        ,test_type_id
                        ,start_date
                        ,end_date
                        ,FVT = 1
                        ,page_spots ='NULL'
                        ,splash_ids = 'NULL'
                        ,control_id
                        ,sql_connection = "RSQL"
                        ,gm_low = NA
                        ,gm_high = NA
                        ,bookings_high = NA
                        ,run_sql_sproc = 2
                        ,no_days_to_order = 7
                        ,filter_out_reorders = 0
                        ,contact_days_threshold = 7
                        ,cohort_dimensions = c("is_new","region","initial_device_type","channel_group")
                        ,days_to_consider = 7
                        ,include_hoppers = 0
                        ,exposed_to_test = 1
                        ,x_axis_day_interval = '1 days'
                        ,additional_constraint = ''
                        ,TCR = 0
                        ,TBPB = 0
                        ,TGPB = 0
                        ,TBPV = 0
                        ,TGPV = 0
                        ,TAOV = 0
                        ,more_visuals = 1
                        ,demo_mode = 0)
{

  time_start = Sys.time()

  require(RODBC)
  require(dplyr)
  require(ggplot2)
  require(scales)
  require(grid)
  require(gridExtra)
  require(proto)
  require(Rcpp)

  msr <- odbcConnect(sql_connection)

  print(paste("Starting MAP functions ",Sys.time()))

  ## based on above information, populate the table and file names in sql
  visitor_table_name <- paste('scratch..msr_vl_',test_type_id,'_',test_id , sep="")
  order_table_name <- paste('scratch..msr_ol_',test_type_id,'_',test_id , sep="")
  credit_table_name <- paste('scratch..msr_ol_',test_type_id,'_',test_id ,'_credit_level', sep="")
  contact_table_name <- paste('scratch..msr_vl_',test_type_id,'_',test_id ,'_contact_level', sep="")
  data_file_name <-   paste('MAP_2_',test_type_id,'_',test_id,'.Rdata',sep="")

  # Execute sql sproc

  ## Visitor sproc if the start date is specified
  if(run_sql_sproc == 2)
  {
    # Need to modify these variables to be used correctly in the visitor sproc
    if(!(page_spots == 'NULL')) {page_spots <- paste("'",page_spots,"'",sep="")}
    if(!(splash_ids == 'NULL')) {splash_ids <- paste("'",splash_ids,"'",sep="")}

    #Call the visitor sproc
    if(test_type_id == 1){sqlQuery(msr,paste("exec scratch..cmsr_visitor  '",start_date,"' , '",end_date, "',",test_id,",",FVT,",",page_spots, ",", splash_ids,sep=""))}
    if(test_type_id == 2){sqlQuery(msr,paste("exec scratch..crm_visitor  '",start_date,"' , '",end_date, "',",test_id,sep=""))}

    print(paste("completed - Visitor sproc ",Sys.time()))
  }

  ## Order MOdule SPROC
  if(run_sql_sproc > 0){
    sqlQuery(msr,paste("exec scratch..msr_module_order ",test_type_id,",",test_id,",",no_days_to_order,sep=""))

    print(paste("completed - Order Sproc ",Sys.time()))

    }

  time_1 = Sys.time()

  # Pull the visitor and order level table (two different ways to pull this information)
  VL <<- msr_import_large_tables(msr, visitor_table_name, 'visitor_id', 4, additional_constraint)
  OL <<- sqlQuery(msr,paste("select * from ", order_table_name,sep =""))
  VBL <<- vistaprintMAP::map_combine_VL_OL(visitor_table = VL,order_table = OL,days_to_consider = days_to_consider)

  print(paste("completed - pulling tables into R ",Sys.time()))

  time_2 = Sys.time()
  # data distribution
  vistaprintMAP::msr_data_distributions(msr,visitor_table_name, test_type_id, x_axis_day_interval,additional_constraint)

  print(paste("completed - Data distribution graphs ",Sys.time()))

  # Remove Visitors with certain values
  ## Remove hoppers
  VBL <<- subset(VBL,is_hopper <= include_hoppers)

  ## Remove if exposed to test constraint
  if(exposed_to_test == 1)
  {VBL <<- subset(VBL,exposed_to_test == 1)}

  ## Remove alt control
  VBL <<- subset(VBL,control_test != 'AC')

  time_3 = Sys.time()
  # Outlier module
  ## outliers module - data

  map_gm_outlier_data <<- vistaprintMAP::msr_outlier_gm_data (order_level_table = OL
                                               , visitor_level_table = VL
                                               , days_to_consider = days_to_consider
                                               , hopper = include_hoppers
                                               , exposedToTest = exposed_to_test
                                               , control_id = control_id)

  map_bkg_outlier_data <<- vistaprintMAP::msr_outlier_booking_data  (order_level_table = OL
                                                      , visitor_level_table = VL
                                                      , days_to_consider = days_to_consider
                                                      , hopper = include_hoppers
                                                      , exposedToTest = exposed_to_test
                                                      , control_id = control_id)
  ### graphs
  vistaprintMAP::msr_outlier_graphs(map_bkg_outlier_data[['output']])
  vistaprintMAP::msr_outlier_graphs(map_gm_outlier_data[['output']],map_gm_outlier_data[['gm_low']])




  print(paste("completed - Outlier Module ",Sys.time()))

  time_4 = Sys.time()
  # get the outlier threshold from the user if not already defined during fucntion call
  if(is.na(gm_low)|is.na(gm_high)|is.na(bookings_high)){
    gm_low  <- as.numeric(readline(prompt="Enter the lower cut off point for GM outlier (mostly between 0.0001 and 0.002) : "))
    gm_high <- as.numeric(readline(prompt="Enter the upper cut off point for GM outlier (mostly between 0.96 and 1  : "))
    bookings_high  <- as.numeric(readline(prompt="Enter the upper cut off point for bookings outlier (mostly between 0.96 and 1  : "))
  }

  # cap the values in the combined visitor buyer table
  VBL <<- vistaprintMAP::map_cap_outliers(VBL,gm_low, gm_high, bookings_high)

  time_5 = Sys.time()

  # summary module

  map_summary_data <<- vistaprintMAP::msr_sm_data(order_level_table = OL
                                   ,visitor_level_table = VL
                                   ,days_to_consider = days_to_consider
                                   , hopper = include_hoppers
                                   , exposedToTest = exposed_to_test
                                   , control_id = control_id
                                   , TCR = TCR
                                   , TGPB = TGPB
                                   , TBPB = TBPB
                                   , TBPV = TBPV
                                   , TGPV = TGPV
                                   , booking_outlier =  bookings_high
                                   , gm_upper_outlier = gm_high
                                   , gm_lower_outlier = gm_low)


  print(paste("completed - Summary data part ",Sys.time()))

  vistaprintMAP::msr_sm_graph(map_summary_data[['output']])

  Sys.sleep(3)

  print(paste("completed - Summary graphs ",Sys.time()))

  time_6 = Sys.time()


  # cohort module
  ## "is_new","region","website_country","channel_group","initial_device_type"

  map_cohort_data <<- vistaprintMAP::msr_cohm_data(order_level_table = OL
                                    ,visitor_level_table = VL
                                    , control_id = control_id
                                    ,cohort_list = cohort_dimensions
                                    ,days_to_consider = days_to_consider
                                    , hopper = include_hoppers
                                    , exposedToTest = exposed_to_test
                                    , booking_outlier =  bookings_high
                                    , gm_upper_outlier = gm_high
                                    , gm_lower_outlier = gm_low)

  print(paste("completed - Cohort data ",Sys.time()))


  vistaprintMAP::msr_cohm_graph(map_cohort_data[['output']][!is.na(map_cohort_data[['output']]$pvalue_cr), ])

  Sys.sleep(3)

  print(paste("completed - Cohort graphs ",Sys.time()))


  time_7 = Sys.time()

  # CARE metrics
  ## Execute SQL SPROC
  ### Care Module - Credit rate sproc

  if(run_sql_sproc > 0){
    sqlQuery(msr,paste("exec scratch..msr_credit '",order_table_name,"',", filter_out_reorders ,",0",sep=""))

    ### Care Module - contact rate sproc
    sqlQuery(msr,paste("exec scratch..msr_contact '",visitor_table_name,"',", contact_days_threshold ,",0",sep=""))

    print(paste("completed - CARE sql sprocs ",Sys.time()))
  }

  Sys.sleep(2)
  ## Execute R funtions
  ### Credit metrics
  map_credit_data <<- vistaprintMAP::msr_care_credit_data(con=msr,
                                           zvalue_bound=1.96,
                                           visitor_table=visitor_table_name,
                                           order_table=order_table_name,
                                           credit_order_table=credit_table_name,
                                           hopper = include_hoppers,
                                           control_id =  control_id,
                                           additional_constraint = additional_constraint)


  print(paste("completed - CARE Credit data ",Sys.time()))

  Sys.sleep(2)
  ### Contact metrics
  map_contact_data <<- vistaprintMAP::msr_care_contact_data(con=msr,
                                             zvalue_bound=1.96,
                                             visitor_table=visitor_table_name,
                                             contact_table=contact_table_name,
                                             hopper = include_hoppers,
                                             control_id =  control_id,
                                             additional_constraint = additional_constraint)


  print(paste("completed - CARE Contact data ",Sys.time()))

  save(map_contact_data,map_credit_data ,  file = paste("//vistaprint.net/common/share/Marketing/Public/Marketing_Analysis/MAP/DoNotTouch/tempdata/care",test_id,".Rdata",sep = ""))

  Sys.sleep(2)

  vistaprintMAP::msr_care_graph(map_credit_data[['output']], map_contact_data[['output']])

  Sys.sleep(5)



  print(paste("completed - CARE graphs  ",Sys.time()))

  time_8 = Sys.time()
  # Daily CR
  ## Pull data
  map_daily_cr_data <<-  vistaprintMAP::msr_sanity_dailyCR_data(order_level_table = OL
                                               , visitor_level_table = VL
                                               ,days_to_consider = days_to_consider
                                               , hopper = include_hoppers
                                               , exposedToTest = exposed_to_test
                                               , control_id = control_id)

  print(paste("completed - Daily metric data ",Sys.time()))

  save(map_daily_cr_data ,  file = paste("//vistaprint.net/common/share/Marketing/Public/Marketing_Analysis/MAP/DoNotTouch/tempdata/daily",test_id,".Rdata",sep = ""))

  ## draw daily CR graph if there is atleast 2 touch dates
  if(length(unique(map_daily_cr_data[['output']]$touch_date)) > 1){
    vistaprintMAP::msr_sanity_dailyCR_graph(map_daily_cr_data[['output']], x_axis_day_interval)
  }

  Sys.sleep(3)

  print(paste("completed - Daily metrics graph  ",Sys.time()))

  time_9 = Sys.time()

  # Cummulative  CR
  map_cumulative_cr_data <<- vistaprintMAP::msr_sanity_cumulativeCR_data(order_level_table = OL
                                                          , visitor_level_table = VL
                                                          ,days_to_consider = days_to_consider
                                                          , hopper = include_hoppers
                                                          , exposedToTest = exposed_to_test
                                                          , control_id = control_id)

  print(paste("completed - Cumulative metrics data  ",Sys.time()))


  if(length(unique(map_cumulative_cr_data[['output']]$dateVariable)) > 1){
    vistaprintMAP::msr_sanity_cumulativeCR_graph (map_cumulative_cr_data[['output']], x_axis_day_interval)
  }

  Sys.sleep(3)

  print(paste("completed - Cumulative metrics graph  ",Sys.time()))


  time_end = Sys.time()



  if(demo_mode == 0){
  # Save the data in a commeon work space
  setwd("//vistaprint.net/common/share/Marketing/Public/Marketing_Analysis/MAP/Test_data")

  map_input <- list(gm_low , gm_high ,bookings_high,additional_constraint,run_sql_sproc)
  names(map_input) <- c('gm_low','gm_high','bookings_high','additional_constraint','rerun_sql_sproc')

  save(map_summary_data,map_cohort_data,map_gm_outlier_data,map_bkg_outlier_data,map_daily_cr_data,map_cumulative_cr_data,map_credit_data, map_contact_data,map_input,  file = data_file_name)
  # save run time details in common space
  load("//vistaprint.net/common/share/Marketing/Public/Marketing_Analysis/MAP/DoNotTouch/MAP_run_history.Rdata")

  MAP_run_temp <- data.frame('ordersproc' = as.numeric(time_1) - as.numeric(time_start),
                             'datapull' = as.numeric(time_2) - as.numeric(time_1),
                             'datadist' = as.numeric(time_3) - as.numeric(time_2),
                             'outlier' = as.numeric(time_4) - as.numeric(time_3),
                             'userentry' = as.numeric(time_5) - as.numeric(time_4),
                             'summary' = as.numeric(time_6) - as.numeric(time_5),
                             'cohort' = as.numeric(time_7) - as.numeric(time_6),
                             'care' = as.numeric(time_8) - as.numeric(time_7),
                             'daily' = as.numeric(time_9) - as.numeric(time_8),
                             'cumulative' = as.numeric(time_end) - as.numeric(time_9),
                             'total_time' = as.numeric(time_end) - as.numeric(time_start),
                             'machine' = Sys.info()[[1]],
                             'user' = Sys.info()[[6]],
                             'MAP_version' = packageDescription("vistaprintMAP")$Version,
                             'test_id' = test_id,
                             'test_type_id' = test_type_id,
                             'rundate' = Sys.time()
                             ,'vis_count' = dim(VL)[1])

  MAP_run_history <- rbind(MAP_run_history,MAP_run_temp)

  save(MAP_run_history,  file = "//vistaprint.net/common/share/Marketing/Public/Marketing_Analysis/MAP/DoNotTouch/MAP_run_history.Rdata")

  }

}

