#' Z score function
#'
#' Returns z score
#' @description Takes in input and returns Z score. Has the ability to restrict z score only if visitor count and order count meets certain threshold
#' @return z scores
#' @export

MAP_z_score <- function(c_mean,t_mean,c_count,t_count,c_var,t_var,
                        #check counts for bounds
                        c_order_count = 25000000, t_order_count = 25000000, c_visitor_count = 25000000, t_visitor_count = 25000000, count_lower_bound = 500,order_count_lower_bound = 30){

  z_score <- ifelse(c_visitor_count <= count_lower_bound | t_visitor_count <= count_lower_bound | c_order_count <= order_count_lower_bound | t_order_count <= order_count_lower_bound,NaN,(t_mean - c_mean)/sqrt((t_var/t_count)+(c_var/c_count)))

  return(z_score)
}



#' Combine visitor level and order level table into visitor_buyer_level table
#' @description Takes in VL and OL table and combines them in visitor buyer level table along with new fields
#' @return a visitor buyer level dataframe including: order_count, booking_usd, gm_usd, any_order_new, AOV and buyer
#' @param visitor_table
#' @param order_table
#' @param date_in the visitors touch date shoudl be equal or higher than this date
#' @param date_out  the visitors touch date should be equal or below than this date
#' @param days_to_consider only order placed within this time period is considered for the analysis
#' @export

map_combine_VL_OL <- function(visitor_table,
                              order_table,
                              date_in = as.Date(min(visitor_table$touch_date)),
                              date_out = as.Date(max(order_table$order_date)),
                              days_to_consider){

  VL <- visitor_table %>%
    filter(as.Date(touch_date) >= date_in & as.Date(touch_date) <= date_out)

  OL <- order_table %>%
    filter(days_from_touch <= days_to_consider & as.Date(order_date) <= date_out)

  BL <- OL %>%
    group_by (visitor_id) %>%
    summarise (order_count = n(),
               booking_usd = sum(booking_usd),
               gm_usd = sum(gm_usd),
               any_new_order = max(order_is_new)) %>%
    mutate (AOV = booking_usd / order_count,
            buyer = 1)

  # Replace the null values with zero for the columns mentioned here.
  VBL <- left_join(VL, BL, by = "visitor_id") %>%
    mutate_each_(funs(replace(., which(is.na(.)), 0)),
                 c('order_count','booking_usd','gm_usd','any_new_order','AOV','buyer'))
  return(VBL)
}




#' A module that will cap bookings and gm based on threshold passed into the function
#' @description A module that will cap bookings and gm based on threshold passed into the function
#' @return a dataframe with capped bookings and gm
#' @param CL_table the visitor buyer level table with booking and gm information
#' @param gm_out_low the lower threshold for gm value
#' @param gm_out_high the higher threshold for gm value
#' @param booking_out_high the higher threshold for bookings_value
#' @export
map_cap_outliers <- function(CL_table, gm_out_low, gm_out_high, booking_out_high)
{
  CL_table_r <- CL_table %>% filter(buyer == 1)

  # Find outliers for bookings & GM and cap them
  # na.rm = TRUE is to remove null values (from visitors who didnt order) before calculating outlier values
  bookings_quantiles <- quantile(CL_table_r$booking_usd, c(booking_out_high))
  GM_quantiles <- quantile(CL_table_r$gm_usd, c(gm_out_low,gm_out_high))

  # Make booking and gm change where appropiate
  CL_table$booking_usd[CL_table$booking_usd > bookings_quantiles[1]] <- bookings_quantiles[1]
  CL_table$gm_usd[CL_table$gm_usd > GM_quantiles[2]] <- GM_quantiles[2]
  CL_table$gm_usd[CL_table$gm_usd < GM_quantiles[1]] <- GM_quantiles[1]

  #print(bookings_quantiles[1])
  #print(GM_quantiles[2])
  #print(GM_quantiles[1])

  return(CL_table)
}





#' multiplot
#'
#' To product subplots
#' @description Produces subplot
#' @return  combined graph
#' @export
multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  library(grid)

  # Make a list from the ... arguments and plotlist
  plots <- c(list(...), plotlist)

  numPlots = length(plots)

  # If layout is NULL, then use 'cols' to determine layout
  if (is.null(layout)) {
    # Make the panel
    # ncol: Number of columns of plots
    # nrow: Number of rows needed, calculated from # of cols
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                     ncol = cols, nrow = ceiling(numPlots/cols))
  }

  if (numPlots==1) {
    print(plots[[1]])

  } else {
    # Set up the page
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))

    # Make each plot, in the correct location
    for (i in 1:numPlots) {
      # Get the i,j matrix positions of the regions that contain this subplot
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))

      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}

#' To ensure that you are using the latest version of vistaprintMAP
#' @description checks if your vistaprintMAP package version no is stale or not
#' @return  an error if your package version is stale
#' @export
check_package_no <- function(){
  load("//vistaprint.net/common/share/Marketing/Public/Marketing_Analysis/MAP/DoNotTouch/package_no.Rdata")
  if (!(packageDescription("vistaprintMAP")$Version %in% xyz_package_no ))
  {  stop(print("You are using an older version of vistaprintMAP package, pls update your package from http://corewiki.cimpress.net/wiki/MAP#MAP_package"))
  }
}

#' To ensure that you are using the latest version of Rmarkdown script
#' @description checks if your Rmarkdown script is stale
#' @return  an error if your package version is stale
#' @export
check_report_no <- function(script_no){
  load("//vistaprint.net/common/share/Marketing/Public/Marketing_Analysis/MAP/DoNotTouch/report_no.Rdata")
  if (!(script_no %in% xyz_report_no ))
  {  stop(print("You are using an old version of the MAP report template, pls update R-markdown template from http://corewiki.cimpress.net/wiki/MAP_templates"))
  }

}




